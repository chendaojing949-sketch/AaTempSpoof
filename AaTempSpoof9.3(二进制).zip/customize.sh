#!/system/bin/sh
SKIPUNZIP=1

unzip -o "$ZIPFILE" -d "$MODPATH" >&2 || abort "解压失败"
rm -rf "$MODPATH/META-INF"

ui_print "================================"
ui_print "   AaTempSpoof v9.3  "
ui_print "   电池/CPU/GPU/内存 温度伪装"
ui_print "   原生二进制守护进程版"
ui_print "================================"

ABI=$(getprop ro.product.cpu.abi)
ui_print "设备 ABI: $ABI"
case "$ABI" in
    arm64*) ui_print "  ✓ arm64 兼容" ;;
    *)      abort "❌ 本模块仅支持 arm64 设备" ;;
esac

[ -f "$MODPATH/bin/AaTempSpoof" ] || abort "❌ 缺少二进制，请先运行 compile_termux.sh 编译"
ui_print "  ✓ 二进制就绪"

found=0
for tz in /sys/class/thermal/thermal_zone*; do [ -f "$tz/emul_temp" ] && found=$((found+1)); done
ui_print "  发现 $found 个 emul_temp 节点"

[ -d /sys/class/power_supply/battery ] && ui_print "  ✓ battery 路径存在" \
                                       || ui_print "  ⚠ battery 路径不存在，电池伪装可能受限"

for C in extreme_gt murongruyan; do
    [ -d "/data/adb/modules/$C" ] && touch "/data/adb/modules/$C/remove" && ui_print "  已标记清理冲突模块: $C"
done

set_perm_recursive "$MODPATH"        0 0 0755 0644
set_perm "$MODPATH/service.sh"       0 0 0755
set_perm "$MODPATH/action.sh"        0 0 0755
set_perm "$MODPATH/uninstall.sh"     0 0 0755
set_perm_recursive "$MODPATH/bin"    0 0 0755 0755 u:object_r:system_file:s0

ui_print " "
ui_print "安装完成！重启后生效"
ui_print "配置: /data/adb/modules/AaTempSpoof/target_temp.txt"
ui_print "日志: /data/adb/modules/AaTempSpoof/tempspoof.log"
ui_print "================================"

am start -a android.intent.action.VIEW -d "https://www.coolapk.com/u/33802586" >/dev/null 2>&1
