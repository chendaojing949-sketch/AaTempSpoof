#!/system/bin/sh
MODDIR=${0%/*}
BIN="$MODDIR/bin/AaTempSpoof"
TARGET="$MODDIR/target_temp.txt"

step() {
    local n="$1" total="$2" label="$3"
    local filled=$(( n * 20 / total )) i=0 bar=""
    while [ $i -lt 20 ]; do
        [ $i -lt $filled ] && bar="${bar}█" || bar="${bar}░"
        i=$((i+1))
    done
    printf "\r  %-14s [%s] %d%%" "$label" "$bar" $(( n * 100 / total ))
}

is_running() {
    pid=$(pgrep -f "$BIN" 2>/dev/null)
    [ -n "$pid" ] && [ -d "/proc/$pid" ]
}

read_config() {
    BATT_EN=1; CPU_EN=1; GPU_EN=1; MEM_EN=1
    BATT_TMP=34; CPU_TMP=37; GPU_TMP=36; MEM_TMP=35
    while IFS='=' read -r key val; do
        case "$key" in
            "电池伪装") BATT_EN=$val  ;;
            "CPU伪装")  CPU_EN=$val   ;;
            "GPU伪装")  GPU_EN=$val   ;;
            "内存伪装") MEM_EN=$val   ;;
            "电池温度") BATT_TMP=$val ;;
            "CPU温度")  CPU_TMP=$val  ;;
            "GPU温度")  GPU_TMP=$val  ;;
            "内存温度") MEM_TMP=$val  ;;
        esac
    done < <(grep -v "^#" "$TARGET" 2>/dev/null | grep "=")
}

CPU_REAL="--"; GPU_REAL="--"; MEM_REAL="--"; BATT_REAL="--"
read_real_temps() {
    for tz in /sys/class/thermal/thermal_zone*; do
        [ -f "$tz/type" ] || continue
        TYPE=$(cat "$tz/type" 2>/dev/null | tr '[:upper:]' '[:lower:]')
        RAW=$(cat "$tz/temp" 2>/dev/null)
        [ -z "$RAW" ] && continue
        case "$TYPE" in
            *cpu*|*cpuss*|*cluster*|*kryo*)   CPU_REAL=$((RAW/1000)) ;;
            *gpu*|*kgsl*|*adreno*)           GPU_REAL=$((RAW/1000)) ;;
            *ddr*|*dram*|*llcc*)             MEM_REAL=$((RAW/1000)) ;;
            *battery*|*bms*|*batt*)          BATT_REAL=$((RAW/1000)) ;;
        esac
    done
}

start_service() {
    is_running && return
    clear
    echo "=============================="
    echo "   正在开启伪装..."
    echo "=============================="
    "$BIN" --start --moddir "$MODDIR" >/dev/null 2>&1

    for i in 1 2 3 4 5 6 7 8 9 10; do
        step $i 10 "初始化"
        sleep 0.15
    done
    printf "\n"

    sleep 0.5
    if is_running; then
        echo "  ✓ 二进制已启动"
    else
        echo "  ✗ 启动失败"
    fi
    sleep 1
}

stop_service() {
    is_running || return
    clear
    echo "=============================="
    echo "   正在关闭伪装..."
    echo "=============================="
    "$BIN" --stop --moddir "$MODDIR" >/dev/null 2>&1

    for i in 1 2 3 4 5; do
        step $i 5 "关闭中"
        sleep 0.15
    done
    printf "\n"

    for i in 1 2 3 4 5; do
        is_running || break
        sleep 0.2
    done

    if is_running; then
        pkill -f "$BIN" 2>/dev/null
    fi

    echo "  ✓ 已关闭"
    sleep 1
}

render_ui() {
    read_config
    read_real_temps

    sw_icon() { [ "$1" = "1" ] && printf "●" || printf "○"; }

    clear
    echo "=============================="
    printf "          AaTempSpoof \n"
    echo "=============================="
    if is_running; then
        echo "  状态: ● 二进制运行中"
    else
        echo "  状态: ○ 二进制未运行"
    fi
    echo "------------------------------"
    printf "  开关: CPU%s GPU%s 内存%s 电池%s\n" \
        "$(sw_icon $CPU_EN)" "$(sw_icon $GPU_EN)" "$(sw_icon $MEM_EN)" "$(sw_icon $BATT_EN)"
    echo "------------------------------"
    echo "  组件  真实  伪装  差值"
    printf "  CPU   %3s°  %3s°  %+d°\n" "${CPU_REAL}"  "$CPU_TMP"  "$((CPU_TMP  - ${CPU_REAL:-0}))"
    printf "  GPU   %3s°  %3s°  %+d°\n" "${GPU_REAL}"  "$GPU_TMP"  "$((GPU_TMP  - ${GPU_REAL:-0}))"
    printf "  内存  %3s°  %3s°  %+d°\n" "${MEM_REAL}"  "$MEM_TMP"  "$((MEM_TMP  - ${MEM_REAL:-0}))"
    printf "  电池  %3s°  %3s°  %+d°\n" "${BATT_REAL}" "$BATT_TMP" "$((BATT_TMP - ${BATT_REAL:-0}))"
    echo "------------------------------"
    echo "  [音量+] 开启伪装"
    echo "  [音量-] 关闭伪装"
    echo "  [电源键] 退出"
    echo "=============================="
}

command -v getevent >/dev/null 2>&1 || exit 1

render_ui

getevent -ql | while read -r line; do
    case "$line" in
        *KEY_VOLUMEUP*DOWN*)
            start_service
            render_ui
            ;;
        *KEY_VOLUMEDOWN*DOWN*)
            stop_service
            render_ui
            ;;
        *KEY_POWER*DOWN*)
            break
            ;;
    esac
done

clear
echo "已退出控制面板"