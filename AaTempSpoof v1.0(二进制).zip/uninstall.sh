#!/system/bin/sh
MODDIR="${0%/*}"; [ -z "$MODDIR" ] && MODDIR="$MODPATH"
BIN="$MODDIR/bin/AaTempSpoof"

if [ -x "$BIN" ]; then
    "$BIN" --stop --moddir "$MODDIR" 2>/dev/null
else
    PF="$MODDIR/daemon.pid"
    [ -f "$PF" ] && kill -9 "$(cat "$PF" 2>/dev/null)" 2>/dev/null
    pkill -9 -f "AaTempSpoof" 2>/dev/null
    for tz in /sys/class/thermal/thermal_zone*/emul_temp; do [ -f "$tz" ] && echo 0 > "$tz" 2>/dev/null; done
    for p in /sys/class/oplus_chg/battery/temp \
             /sys/class/oplus_chg/battery/batt_temp \
             /sys/devices/platform/soc/soc:oplus,mms_gauge/oplus_mms/gauge/battery/temp; do
        umount "$p" 2>/dev/null; done
    umount /sys/class/power_supply/battery/temp 2>/dev/null
    umount /sys/class/power_supply/battery 2>/dev/null
fi

rm -f  "$MODDIR/daemon.pid" "$MODDIR/.enable" "$MODDIR/fake_batt_temp" "$MODDIR/tempspoof.log"
rm -rf "$MODDIR/overlay" "$MODDIR/work" "$MODDIR/upper"
exit 0
