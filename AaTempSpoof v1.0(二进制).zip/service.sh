#!/system/bin/sh

MODDIR="${0%/*}"
BIN="$MODDIR/bin/AaTempSpoof"
LOG="$MODDIR/tempspoof.log"


if [ -f "$LOG" ] && [ "$(wc -l < "$LOG" 2>/dev/null)" -gt 500 ]; then
    tail -n 100 "$LOG" > "${LOG}.tmp" && mv "${LOG}.tmp" "$LOG"
fi
printf '%s [service.sh] 启动\n' "$(date '+%H:%M:%S')" >> "$LOG"

[ -x "$BIN" ] || { printf '%s [service.sh] 错误: %s 不可执行\n' "$(date '+%H:%M:%S')" "$BIN" >> "$LOG"; exit 1; }


PIDFILE="$MODDIR/daemon.pid"
if [ -f "$PIDFILE" ]; then
    OLD=$(cat "$PIDFILE" 2>/dev/null)
    case "$OLD" in ''|*[!0-9]*) ;; *) kill -0 "$OLD" 2>/dev/null && exit 0 ;; esac
fi

"$BIN" --start --moddir "$MODDIR"
printf '%s [service.sh] --start 已调用\n' "$(date '+%H:%M:%S')" >> "$LOG"
